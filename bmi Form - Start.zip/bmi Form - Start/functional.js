const express=require("express");
const bodyParser=require("body-parser");
const exp = require("constants");



const app=express();
app.set('view engine','ejs')
app.use(express.static("public"))
app.use(bodyParser.urlencoded({extended: true}));


app.get('/',(req,res)=>{



    var number1=0;

   
    

    res.render('bmi',{bmiResult: " " ,age1:"",h1:"",w1:""})
    



})

app.post('/',(req,res)=>{



    var age=Number(req.body.age);
    var height=Number(req.body.height);
    var weight=Number(req.body.weight);
    var bmi=(weight*100*100)/(height*height);
    var Result='Your BMI result is:'+bmi;
    
    res.render('bmi',{bmiResult: Result,age1:age,h1:height,w1:weight})

   
    
    
    
    
    



})



app.listen(3000,()=>{


    console.log("Server is running");
})